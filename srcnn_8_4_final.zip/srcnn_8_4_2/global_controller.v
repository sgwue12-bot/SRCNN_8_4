`timescale 1ns / 1ps

//============================================================================
// Global Controller for SRCNN_8_4 streaming architecture
//----------------------------------------------------------------------------
// Role:
//   - Start whole SRCNN operation
//   - Generate frame_start pulse for each image
//   - Manage frame index: 0, 1, 2
//   - Enable Layer1 input feeder
//   - Wait until current image output is completely written
//   - Assert o_done once per completed image
//
// Board protocol:
//   image0 complete -> o_done 1 pulse
//   image1 complete -> o_done 1 pulse
//   image2 complete -> o_done 1 pulse, then return to IDLE
//
// Important:
//   i_output_last_pixel should be delayed in SRCNN.v so that o_done occurs
//   after the final packed output word has safely been written.
//============================================================================

module global_controller #(
    parameter NUM_IMG = 3
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       i_start,

    // Layer1 feeder done for current image
    input  wire       i_l1_feed_done,

    // Current image final output pixel completed
    // In current design, this signal should already be delayed by SRCNN.v.
    input  wire       i_output_last_pixel,

    // One-cycle pulse at the start of each image frame
    output reg        o_frame_start,

    // Enable Layer1 input feeding
    output wire       o_l1_enable,

    // Current image index: 0, 1, 2
    output reg [1:0]  o_frame_idx,

    // Done pulse per image
    output reg        o_done
);

    localparam S_IDLE        = 2'd0;
    localparam S_FRAME_START = 2'd1;
    localparam S_FEED_L1     = 2'd2;
    localparam S_WAIT_FRAME  = 2'd3;

    reg [1:0] state;

    assign o_l1_enable = (state == S_FEED_L1);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= S_IDLE;
            o_frame_idx   <= 2'd0;
            o_frame_start <= 1'b0;
            o_done        <= 1'b0;
        end else begin
            // default pulse signals
            o_frame_start <= 1'b0;
            o_done        <= 1'b0;

            case (state)
                S_IDLE: begin
                    if (i_start) begin
                        o_frame_idx <= 2'd0;
                        state       <= S_FRAME_START;
                    end
                end

                S_FRAME_START: begin
                    // Reset/initialize local controllers and line buffers
                    // for the current frame.
                    o_frame_start <= 1'b1;
                    state         <= S_FEED_L1;
                end

                S_FEED_L1: begin
                    // Layer1 controller feeds real image rows and bottom
                    // padding row into Layer1 line buffer.
                    if (i_l1_feed_done) begin
                        state <= S_WAIT_FRAME;
                    end
                end

                S_WAIT_FRAME: begin
                    // Wait until current image output has fully completed.
                    if (i_output_last_pixel) begin
                        // Board protocol: done pulse once per image.
                        o_done <= 1'b1;

                        if (o_frame_idx == (NUM_IMG-1)) begin
                            // All 3 images completed.
                            state <= S_IDLE;
                        end else begin
                            // Move to next image.
                            o_frame_idx <= o_frame_idx + 2'd1;
                            state       <= S_FRAME_START;
                        end
                    end
                end

                default: begin
                    state <= S_IDLE;
                end
            endcase
        end
    end

endmodule