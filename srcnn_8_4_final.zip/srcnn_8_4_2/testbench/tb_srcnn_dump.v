`timescale 1ns / 1ps

//==============================================================================
// tb_srcnn_dump_wait3_full.v
//------------------------------------------------------------------------------
// - Waits for 3 done pulses. Current global_controller should assert done once
//   per image.
// - Captures Layer1 / Layer2 / Layer3 / final output.
// - Dumps files in reference order.
//   Layer1: ch0 full image, ch1 full image, ... ch7 full image
//   Layer2: ch0 full image, ch1 full image, ... ch3 full image
//   Layer3/final: row-major 150x150
//==============================================================================
// output_hex check
module tb_srcnn_dump;

    parameter DATA_WIDTH = 16;
    parameter ADDR_WIDTH = 17;

    parameter IMG_H      = 150;
    parameter IMG_W      = 150;
    parameter IMG_PIXELS = IMG_H * IMG_W;
    parameter N_IMG      = 3;

    parameter L1_CH      = 8;
    parameter L2_CH      = 4;

    parameter L1_TOTAL   = IMG_PIXELS * L1_CH;
    parameter L2_TOTAL   = IMG_PIXELS * L2_CH;

    parameter MAX_CYCLES = 200000;

    reg clk;
    reg rst_n;
    reg start;

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;  // 100 MHz
    end

    wire done;
    wire                         output_bram_wen;
    wire [ADDR_WIDTH-1:0]         output_bram_waddr;
    wire signed [DATA_WIDTH-1:0]  L3_p_out;

SRCNN dut (
    .i_clk             (clk),
    .i_rstn            (rst_n),
    .i_start           (start),

    .o_done            (done),

    .output_bram_wen   (output_bram_wen),
    .output_bram_waddr (output_bram_waddr),
    .L3_p_out          (L3_p_out)
);

    reg [DATA_WIDTH-1:0] l1_mem0 [0:L1_TOTAL-1];
    reg [DATA_WIDTH-1:0] l1_mem1 [0:L1_TOTAL-1];
    reg [DATA_WIDTH-1:0] l1_mem2 [0:L1_TOTAL-1];

    reg [DATA_WIDTH-1:0] l2_mem0 [0:L2_TOTAL-1];
    reg [DATA_WIDTH-1:0] l2_mem1 [0:L2_TOTAL-1];
    reg [DATA_WIDTH-1:0] l2_mem2 [0:L2_TOTAL-1];

    reg [DATA_WIDTH-1:0] l3_mem0 [0:IMG_PIXELS-1];
    reg [DATA_WIDTH-1:0] l3_mem1 [0:IMG_PIXELS-1];
    reg [DATA_WIDTH-1:0] l3_mem2 [0:IMG_PIXELS-1];

    reg [DATA_WIDTH-1:0] final_mem0 [0:IMG_PIXELS-1];
    reg [DATA_WIDTH-1:0] final_mem1 [0:IMG_PIXELS-1];
    reg [DATA_WIDTH-1:0] final_mem2 [0:IMG_PIXELS-1];

    integer l1_cnt0, l1_cnt1, l1_cnt2;
    integer l2_cnt0, l2_cnt1, l2_cnt2;
    integer l3_cnt0, l3_cnt1, l3_cnt2;
    integer out_cnt0, out_cnt1, out_cnt2;

    integer ch;
    integer final_local_addr;

    //-------------------------------------------------------------------------
    // Capture internal layer outputs.
    // Required hierarchical signal names in SRCNN.v:
    //   dut.frame_idx
    //   dut.l1_out_valid, dut.l1_out_flat
    //   dut.l2_out_valid, dut.l2_out_flat
    //   dut.l3_out_valid, dut.l3_out_data
    //-------------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            l1_cnt0 <= 0; l1_cnt1 <= 0; l1_cnt2 <= 0;
            l2_cnt0 <= 0; l2_cnt1 <= 0; l2_cnt2 <= 0;
            l3_cnt0 <= 0; l3_cnt1 <= 0; l3_cnt2 <= 0;
            out_cnt0 <= 0; out_cnt1 <= 0; out_cnt2 <= 0;
        end else begin
            if (dut.l1_out_valid) begin
                if (dut.frame_idx == 2'd0 && l1_cnt0 < IMG_PIXELS) begin
                    for (ch = 0; ch < L1_CH; ch = ch + 1)
                        l1_mem0[l1_cnt0*L1_CH + ch] <= dut.l1_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l1_cnt0 <= l1_cnt0 + 1;
                end else if (dut.frame_idx == 2'd1 && l1_cnt1 < IMG_PIXELS) begin
                    for (ch = 0; ch < L1_CH; ch = ch + 1)
                        l1_mem1[l1_cnt1*L1_CH + ch] <= dut.l1_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l1_cnt1 <= l1_cnt1 + 1;
                end else if (dut.frame_idx == 2'd2 && l1_cnt2 < IMG_PIXELS) begin
                    for (ch = 0; ch < L1_CH; ch = ch + 1)
                        l1_mem2[l1_cnt2*L1_CH + ch] <= dut.l1_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l1_cnt2 <= l1_cnt2 + 1;
                end
            end

            if (dut.l2_out_valid) begin
                if (dut.frame_idx == 2'd0 && l2_cnt0 < IMG_PIXELS) begin
                    for (ch = 0; ch < L2_CH; ch = ch + 1)
                        l2_mem0[l2_cnt0*L2_CH + ch] <= dut.l2_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l2_cnt0 <= l2_cnt0 + 1;
                end else if (dut.frame_idx == 2'd1 && l2_cnt1 < IMG_PIXELS) begin
                    for (ch = 0; ch < L2_CH; ch = ch + 1)
                        l2_mem1[l2_cnt1*L2_CH + ch] <= dut.l2_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l2_cnt1 <= l2_cnt1 + 1;
                end else if (dut.frame_idx == 2'd2 && l2_cnt2 < IMG_PIXELS) begin
                    for (ch = 0; ch < L2_CH; ch = ch + 1)
                        l2_mem2[l2_cnt2*L2_CH + ch] <= dut.l2_out_flat[ch*DATA_WIDTH +: DATA_WIDTH];
                    l2_cnt2 <= l2_cnt2 + 1;
                end
            end

            if (dut.l3_out_valid) begin
                if (dut.frame_idx == 2'd0 && l3_cnt0 < IMG_PIXELS) begin
                    l3_mem0[l3_cnt0] <= dut.l3_out_data;
                    l3_cnt0 <= l3_cnt0 + 1;
                end else if (dut.frame_idx == 2'd1 && l3_cnt1 < IMG_PIXELS) begin
                    l3_mem1[l3_cnt1] <= dut.l3_out_data;
                    l3_cnt1 <= l3_cnt1 + 1;
                end else if (dut.frame_idx == 2'd2 && l3_cnt2 < IMG_PIXELS) begin
                    l3_mem2[l3_cnt2] <= dut.l3_out_data;
                    l3_cnt2 <= l3_cnt2 + 1;
                end
            end

            if (output_bram_wen) begin
                if (output_bram_waddr < IMG_PIXELS) begin
                    final_mem0[output_bram_waddr] <= L3_p_out;
                    out_cnt0 <= out_cnt0 + 1;
                end else if (output_bram_waddr < 2*IMG_PIXELS) begin
                    final_local_addr = output_bram_waddr - IMG_PIXELS;
                    final_mem1[final_local_addr] <= L3_p_out;
                    out_cnt1 <= out_cnt1 + 1;
                end else if (output_bram_waddr < 3*IMG_PIXELS) begin
                    final_local_addr = output_bram_waddr - 2*IMG_PIXELS;
                    final_mem2[final_local_addr] <= L3_p_out;
                    out_cnt2 <= out_cnt2 + 1;
                end
            end
        end
    end

    integer fd_l1_0, fd_l1_1, fd_l1_2, fd_l1_all;
    integer fd_l2_0, fd_l2_1, fd_l2_2, fd_l2_all;
    integer fd_l3_0, fd_l3_1, fd_l3_2, fd_l3_all;
    integer fd_out_0, fd_out_1, fd_out_2, fd_out_all;

    task open_files;
    begin
        // Make sure this directory exists. Use '/' separators.
        fd_l1_0 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer1_output_test_0.txt", "w");
        fd_l1_1 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer1_output_test_1.txt", "w");
        fd_l1_2 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer1_output_test_2.txt", "w");
     

        fd_l2_0 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer2_output_test_0.txt", "w");
        fd_l2_1 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer2_output_test_1.txt", "w");
        fd_l2_2 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer2_output_test_2.txt", "w");

        fd_l3_0 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer3_output_test_0.txt", "w");
        fd_l3_1 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer3_output_test_1.txt", "w");
        fd_l3_2 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/layer3_output_test_2.txt", "w");

        fd_out_0 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/output_test_0.txt", "w");
        fd_out_1 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/output_test_1.txt", "w");
        fd_out_2 = $fopen("../../../../../01_Reference_SW/srcnn_8_4_output_dump/output_test_2.txt", "w");;

if (fd_l1_0 <= 0 || fd_l1_1 <= 0 || fd_l1_2 <= 0 ||
    fd_l2_0 <= 0 || fd_l2_1 <= 0 || fd_l2_2 <= 0 ||
    fd_l3_0 <= 0 || fd_l3_1 <= 0 || fd_l3_2 <= 0 ||
    fd_out_0 <= 0 || fd_out_1 <= 0 || fd_out_2 <= 0) begin
            $display("ERROR: Failed to open one or more output files. Check output directory.");
            $finish;
        end
    end
    endtask

    task dump_files;
        integer p;
        integer c;
    begin
        // Layer1: channel-major, image0/1/2
        for (c = 0; c < L1_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l1_0, "%04h", l1_mem0[p*L1_CH + c]);
            end
        end
        for (c = 0; c < L1_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l1_1, "%04h", l1_mem1[p*L1_CH + c]);
            end
        end
        for (c = 0; c < L1_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l1_2, "%04h", l1_mem2[p*L1_CH + c]);
            end
        end

        // Layer2: channel-major, image0/1/2
        for (c = 0; c < L2_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l2_0, "%04h", l2_mem0[p*L2_CH + c]);
            end
        end
        for (c = 0; c < L2_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l2_1, "%04h", l2_mem1[p*L2_CH + c]);
            end
        end
        for (c = 0; c < L2_CH; c = c + 1) begin
            for (p = 0; p < IMG_PIXELS; p = p + 1) begin
                $fdisplay(fd_l2_2, "%04h", l2_mem2[p*L2_CH + c]);
            end
        end

        // Layer3: row-major
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_l3_0, "%04h", l3_mem0[p]);
        end
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_l3_1, "%04h", l3_mem1[p]);
        end
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_l3_2, "%04h", l3_mem2[p]);
        end

        // Final output: row-major
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_out_0, "%04h", final_mem0[p]);
        end
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_out_1, "%04h", final_mem1[p]);
        end
        for (p = 0; p < IMG_PIXELS; p = p + 1) begin
            $fdisplay(fd_out_2, "%04h", final_mem2[p]);
        end

        $display("INFO: Reference-order dump files written.");
    end
    endtask

    task close_files;
    begin
        $fclose(fd_l1_0); $fclose(fd_l1_1); $fclose(fd_l1_2);
        $fclose(fd_l2_0); $fclose(fd_l2_1); $fclose(fd_l2_2); 
        $fclose(fd_l3_0); $fclose(fd_l3_1); $fclose(fd_l3_2); 
        $fclose(fd_out_0); $fclose(fd_out_1); $fclose(fd_out_2); 
    end
    endtask

    integer cycle_count;
    integer done_count;
    reg prev_done;

    initial begin
        open_files();

        rst_n = 1'b0;
        start = 1'b0;
        cycle_count = 0;
        done_count  = 0;
        prev_done   = 1'b0;

        repeat (10) @(posedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);

        @(posedge clk);
        start = 1'b1;
        @(posedge clk);
        start = 1'b0;

        while (done_count < 3 && cycle_count < MAX_CYCLES) begin
            @(posedge clk);
            #1;
            cycle_count = cycle_count + 1;

            if (done && !prev_done) begin
                done_count = done_count + 1;
                $display("INFO: done pulse %0d detected at cycle %0d", done_count, cycle_count);
            end
            prev_done = done;
        end

        if (done_count < 3) begin
            $display("ERROR: Simulation timeout. done_count=%0d cycle=%0d", done_count, cycle_count);
            close_files();
            $finish;
        end

        repeat (50) @(posedge clk);

        $display("INFO: SRCNN 3-image simulation done at cycle %0d", cycle_count);
        $display("INFO: captured pixels L1=(%0d,%0d,%0d), L2=(%0d,%0d,%0d), L3=(%0d,%0d,%0d), OUT=(%0d,%0d,%0d)",
                 l1_cnt0, l1_cnt1, l1_cnt2,
                 l2_cnt0, l2_cnt1, l2_cnt2,
                 l3_cnt0, l3_cnt1, l3_cnt2,
                 out_cnt0, out_cnt1, out_cnt2);

        dump_files();
        close_files();
        $finish;
    end

endmodule
