`timescale 1ns/1ps
// running time check
module tb_top_srcnn;

reg clk;
reg rstn;
reg i_start;

wire done_intr_o;

top_srcnn dut (
    .clk(clk),
    .rstn(rstn),
    .i_start(i_start),
    .done_intr_o(done_intr_o)
);

initial begin
    clk = 0;
    forever #5 clk = ~clk;    // 100MHz
end

integer cycles;
integer done_count;
reg prev_done;

initial begin

    rstn = 0;
    i_start = 0;

    cycles = 0;
    done_count = 0;
    prev_done = 0;

    repeat(20) @(posedge clk);
    rstn = 1;

    repeat(10) @(posedge clk);

    i_start = 1;
    @(posedge clk);
    i_start = 0;

    while (done_count < 3 && cycles < 300000) begin
        @(posedge clk);

        cycles = cycles + 1;

        if (done_intr_o && !prev_done) begin
            done_count = done_count + 1;
            $display("done pulse %0d at cycle %0d",
                     done_count,
                     cycles);
        end

        prev_done = done_intr_o;
    end

    if (done_count == 3) begin
        $display("================================");
        $display("ALL 3 IMAGES FINISHED");
        $display("cycles = %0d", cycles);
        $display("time   = %0.6f ms", cycles * 0.00001);
        $display("================================");
    end
    else begin
        $display("TIMEOUT");
    end

    $finish;

end

endmodule