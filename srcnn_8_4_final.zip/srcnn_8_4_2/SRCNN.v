//============================================================================
// Copyright (c) 2026 Seoul National University of Science and Technology
//                     (SEOULTECH)
//                     Intelligence Digital System Design Lab (IDSL)
//
// Course: Digital System Design, Spring 2026
//
// This source code is provided as educational material for the
// Digital System Design course at SEOULTECH. It is released under
// the MIT License to encourage learning and reuse.
//
// SPDX-License-Identifier: MIT
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject
// to the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
// BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
// ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//============================================================================

`timescale 1ns / 1ps

module SRCNN #(
    //============================================================================
    // Do not modify this parameter
    //============================================================================
    parameter IN_ADDR_WIDTH = 17,
    parameter IN_WIDTH      = 16
)(
    //============================================================================
    // Do not modify this ports
    //============================================================================
    input  wire                     i_clk,
    input  wire                     i_rstn,
    input  wire                     i_start,

    output wire                     o_done,
    output wire                     output_bram_wen,
    output wire [IN_ADDR_WIDTH-1:0] output_bram_waddr,
    output wire [IN_WIDTH-1:0]      L3_p_out
);

    // -------------------------------------------------------------------------
    // Local parameters
    // -------------------------------------------------------------------------
    localparam IMG_W        = 150;
    localparam IMG_H        = 150;
    localparam PIX_PER_IMG  = 22500;
    localparam NUM_IMG      = 3;
    localparam TOTAL_PIXELS = 67500;

    // -------------------------------------------------------------------------
    // Global controller
    // -------------------------------------------------------------------------
    wire        frame_start;
    wire        l1_enable;
    wire [1:0]  frame_idx;
    wire        l1_feed_done;
    wire        output_last_pixel;
    wire                         l3_out_valid;
    wire [7:0]                   l3_out_row;
    wire [7:0]                   l3_out_col;
    wire signed [IN_WIDTH-1:0]   l3_out_data;

    global_controller #(
        .NUM_IMG(NUM_IMG)
    ) u_global_controller (
        .clk                 (i_clk),
        .rst_n               (i_rstn),
        .i_start             (i_start),
        .i_l1_feed_done      (l1_feed_done),
        .i_output_last_pixel (output_last_pixel),
        .o_frame_start       (frame_start),
        .o_l1_enable         (l1_enable),
        .o_frame_idx         (frame_idx),
        .o_done              (o_done)
    );

    // -------------------------------------------------------------------------
    // Input memory and weight/bias ROM
    // -------------------------------------------------------------------------
    wire [IN_ADDR_WIDTH-1:0] l1_local_input_addr;
    wire [IN_ADDR_WIDTH-1:0] input_addr;
    wire signed [IN_WIDTH-1:0] input_mem_data;

    wire [IN_ADDR_WIDTH-1:0] input_frame_base =
        (frame_idx == 2'd0) ? 17'd0     :
        (frame_idx == 2'd1) ? 17'd22500 :
                             17'd45000;

    // layer1_stream_ctrl is forced to generate only local 0~22499 addresses.
    // SRCNN.v adds the frame offset here to guarantee different images are read.
    assign input_addr = input_frame_base + l1_local_input_addr;

    input_mem_3img #(
        .ADDR_WIDTH(IN_ADDR_WIDTH),
        .DATA_WIDTH(IN_WIDTH),
        .DEPTH(TOTAL_PIXELS)
    ) u_input_mem (
        .clk    (i_clk),
        .i_addr (input_addr),
        .o_data (input_mem_data)
    );

    wire signed [72*IN_WIDTH-1:0]  w1_flat;
    wire signed [288*IN_WIDTH-1:0] w2_flat;
    wire signed [36*IN_WIDTH-1:0]  w3_flat;
    wire signed [8*IN_WIDTH-1:0]   b1_flat;
    wire signed [4*IN_WIDTH-1:0]   b2_flat;
    wire signed [IN_WIDTH-1:0]     b3_wire;

    weight_bias_mem_8_4 #(
        .DATA_WIDTH(IN_WIDTH)
    ) u_weight_bias_mem (
        .o_w1_flat (w1_flat),
        .o_w2_flat (w2_flat),
        .o_w3_flat (w3_flat),
        .o_b1_flat (b1_flat),
        .o_b2_flat (b2_flat),
        .o_b3      (b3_wire)
    );

    // -------------------------------------------------------------------------
    // Layer1 input controller and line buffer
    // -------------------------------------------------------------------------
    wire                         l1_line_ready;
    wire                         l1_feed_valid;
    wire signed [IN_WIDTH-1:0]   l1_input_pixel;

    layer1_stream_ctrl #(
        .DATA_WIDTH (IN_WIDTH),
        .IMG_W      (IMG_W),
        .IMG_H      (IMG_H),
        .ADDR_WIDTH (IN_ADDR_WIDTH)
    ) u_layer1_stream_ctrl (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_frame_start (frame_start),
        .i_enable      (l1_enable),

        // Force controller-local addressing. The real frame offset is added
        // in SRCNN.v using frame_idx from global_controller.
        .i_frame_idx   (2'd0),

        .i_line_ready  (l1_line_ready),
        .i_mem_data    (input_mem_data),
        .o_feed_valid  (l1_feed_valid),
        .o_feed_data   (l1_input_pixel),
        .o_input_addr  (l1_local_input_addr),
        .o_feed_done   (l1_feed_done)
    );

    wire        l1_win_valid;
    wire [7:0]  l1_win_row;
    wire [7:0]  l1_win_col;
    wire signed [IN_WIDTH-1:0] l1_w00, l1_w01, l1_w02;
    wire signed [IN_WIDTH-1:0] l1_w10, l1_w11, l1_w12;
    wire signed [IN_WIDTH-1:0] l1_w20, l1_w21, l1_w22;

    line_buffer_3x150_1ch u_l1_linebuf (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_frame_start (frame_start),
        .i_valid       (l1_feed_valid),
        .i_data        (l1_input_pixel),
        .o_in_ready    (l1_line_ready),
        .o_win_valid   (l1_win_valid),
        .o_out_row     (l1_win_row),
        .o_out_col     (l1_win_col),
        .o_win_00      (l1_w00),
        .o_win_01      (l1_w01),
        .o_win_02      (l1_w02),
        .o_win_10      (l1_w10),
        .o_win_11      (l1_w11),
        .o_win_12      (l1_w12),
        .o_win_20      (l1_w20),
        .o_win_21      (l1_w21),
        .o_win_22      (l1_w22)
    );

    // Keep these signal names for testbench hierarchical dump.
    wire                         l1_out_valid;
    wire [7:0]                   l1_out_row;
    wire [7:0]                   l1_out_col;
    wire signed [8*IN_WIDTH-1:0] l1_out_flat;

    layer1_conv_8ch u_l1_conv (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_valid       (l1_win_valid),
        .i_row         (l1_win_row),
        .i_col         (l1_win_col),
        .i_win_00      (l1_w00),
        .i_win_01      (l1_w01),
        .i_win_02      (l1_w02),
        .i_win_10      (l1_w10),
        .i_win_11      (l1_w11),
        .i_win_12      (l1_w12),
        .i_win_20      (l1_w20),
        .i_win_21      (l1_w21),
        .i_win_22      (l1_w22),
        .i_weight_flat (w1_flat),
        .i_bias_flat   (b1_flat),
        .o_valid       (l1_out_valid),
        .o_row         (l1_out_row),
        .o_col         (l1_out_col),
        .o_data_flat   (l1_out_flat)
    );

    // -------------------------------------------------------------------------
    // Layer2 line buffer controller + line buffer + convolution
    // -------------------------------------------------------------------------
    wire                         l2_line_ready;
    wire                         l2_in_valid;
    wire signed [8*IN_WIDTH-1:0] l2_in_data_flat;
    wire                         l2_pad_active_unused;

    layer2_local_ctrl #(
        .DATA_WIDTH(IN_WIDTH),
        .IN_CH     (8),
        .IMG_W     (IMG_W)
    ) u_layer2_local_ctrl (
        .clk              (i_clk),
        .rst_n            (i_rstn),
        .i_frame_start    (frame_start),
        .i_l1_valid       (l1_out_valid),
        .i_l1_row         (l1_out_row),
        .i_l1_col         (l1_out_col),
        .i_l1_data_flat   (l1_out_flat),
        .i_line_ready     (l2_line_ready),
        .o_l2_in_valid    (l2_in_valid),
        .o_l2_in_data_flat(l2_in_data_flat),
        .o_pad_active     (l2_pad_active_unused)
    );

    wire                         l2_win_valid;
    wire [7:0]                   l2_win_row;
    wire [7:0]                   l2_win_col;
    wire signed [8*9*IN_WIDTH-1:0] l2_win_flat;

    layer2_linebuf_8ch u_l2_linebuf (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_frame_start (frame_start),
        .i_valid       (l2_in_valid),
        .i_data_flat   (l2_in_data_flat),
        .o_in_ready    (l2_line_ready),
        .o_win_valid   (l2_win_valid),
        .o_out_row     (l2_win_row),
        .o_out_col     (l2_win_col),
        .o_win_flat    (l2_win_flat)
    );

    wire                         l2_out_valid;
    wire [7:0]                   l2_out_row;
    wire [7:0]                   l2_out_col;
    wire signed [4*IN_WIDTH-1:0] l2_out_flat;

    layer2_conv_4ch u_l2_conv (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_valid       (l2_win_valid),
        .i_row         (l2_win_row),
        .i_col         (l2_win_col),
        .i_win_flat    (l2_win_flat),
        .i_weight_flat (w2_flat),
        .i_bias_flat   (b2_flat),
        .o_valid       (l2_out_valid),
        .o_row         (l2_out_row),
        .o_col         (l2_out_col),
        .o_data_flat   (l2_out_flat)
    );

    // -------------------------------------------------------------------------
    // Layer3 line buffer controller + line buffer + convolution
    // -------------------------------------------------------------------------
    wire                         l3_line_ready;
    wire                         l3_in_valid;
    wire signed [4*IN_WIDTH-1:0] l3_in_data_flat;
    wire                         l3_pad_active_unused;

    layer3_local_ctrl #(
        .DATA_WIDTH(IN_WIDTH),
        .IN_CH     (4),
        .IMG_W     (IMG_W),
        .IMG_H     (IMG_H),
        .ADDR_WIDTH(IN_ADDR_WIDTH),
        .DONE_DELAY(32)
    ) u_layer3_local_ctrl (
        .clk                  (i_clk),
        .rst_n                (i_rstn),
        .i_frame_start        (frame_start),
        .i_frame_idx          (frame_idx),

        .i_l2_valid           (l2_out_valid),
        .i_l2_row             (l2_out_row),
        .i_l2_col             (l2_out_col),
        .i_l2_data_flat       (l2_out_flat),
        .i_line_ready         (l3_line_ready),
        .o_l3_in_valid        (l3_in_valid),
        .o_l3_in_data_flat    (l3_in_data_flat),
        .o_pad_active         (l3_pad_active_unused),

        .i_l3_out_valid       (l3_out_valid),
        .i_l3_out_row         (l3_out_row),
        .i_l3_out_col         (l3_out_col),
        .i_l3_out_data        (l3_out_data),

        .o_output_bram_wen    (output_bram_wen),
        .o_output_bram_waddr  (output_bram_waddr),
        .o_L3_p_out           (L3_p_out),
        .o_output_last_pixel  (output_last_pixel)
    );

    wire                         l3_win_valid;
    wire [7:0]                   l3_win_row;
    wire [7:0]                   l3_win_col;
    wire signed [4*9*IN_WIDTH-1:0] l3_win_flat;

    layer3_linebuf_4ch u_l3_linebuf (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_frame_start (frame_start),
        .i_valid       (l3_in_valid),
        .i_data_flat   (l3_in_data_flat),
        .o_in_ready    (l3_line_ready),
        .o_win_valid   (l3_win_valid),
        .o_out_row     (l3_win_row),
        .o_out_col     (l3_win_col),
        .o_win_flat    (l3_win_flat)
    );



    layer3_conv_1ch u_l3_conv (
        .clk           (i_clk),
        .rst_n         (i_rstn),
        .i_valid       (l3_win_valid),
        .i_row         (l3_win_row),
        .i_col         (l3_win_col),
        .i_win_flat    (l3_win_flat),
        .i_weight_flat (w3_flat),
        .i_bias        (b3_wire),
        .o_valid       (l3_out_valid),
        .o_row         (l3_out_row),
        .o_col         (l3_out_col),
        .o_data        (l3_out_data)
    );

    // -------------------------------------------------------------------------
    // Output write interface
    // -------------------------------------------------------------------------
    // Final output write control is intentionally handled inside
    // layer3_local_ctrl. This matches the previous board-verified structure:
    //   Layer3 conv output -> registered output controller -> top_srcnn packing
    // Therefore output_bram_wen/output_bram_waddr/L3_p_out are not generated
    // by direct assign statements in SRCNN.v.

endmodule
