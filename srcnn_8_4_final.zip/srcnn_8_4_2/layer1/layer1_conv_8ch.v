`timescale 1ns / 1ps

//============================================================================
// Layer1 convolution block for SRCNN_8_4
//----------------------------------------------------------------------------
// Function:
//   1 input-channel 3x3 window -> 8 output-channel pixels
//
// Architecture:
//   - mac_core x 72 = 8 output channels x 9 kernel taps
//   - Product register stage to cut multiplier/adder timing path
//   - q8_8_unit x 8 : (MAC accumulation >>> 8) + bias + saturation
//   - relu x 8      : Layer1 activation
//
// Fixed-point order, IMPORTANT:
//   Q8.8 input x Q8.8 weight -> Q16.16 product
//   Sum 9 products            -> wide accumulator
//   q8_8_unit                 -> arithmetic shift right by 8, then bias add
//   relu                      -> Layer1 ReLU
//
// Weight flat order:
//   i_weight_flat[(out_ch*9 + tap)*16 +: 16]
//
// Tap order:
//   tap0 tap1 tap2  = win00 win01 win02
//   tap3 tap4 tap5  = win10 win11 win12
//   tap6 tap7 tap8  = win20 win21 win22
//
// Output flat order:
//   o_data_flat[out_ch*16 +: 16]
//
// Timing:
//   - Accepts one valid 3x3 window per cycle when i_valid=1.
//   - o_valid is asserted 1 clock after the corresponding i_valid.
//============================================================================

module layer1_conv_8ch #(
    parameter DATA_WIDTH = 16,
    parameter ACC_WIDTH  = 48,
    parameter OUT_CH     = 8
)(
    input  wire                         clk,
    input  wire                         rst_n,

    input  wire                         i_valid,
    input  wire [7:0]                   i_row,
    input  wire [7:0]                   i_col,

    input  wire signed [DATA_WIDTH-1:0] i_win_00,
    input  wire signed [DATA_WIDTH-1:0] i_win_01,
    input  wire signed [DATA_WIDTH-1:0] i_win_02,
    input  wire signed [DATA_WIDTH-1:0] i_win_10,
    input  wire signed [DATA_WIDTH-1:0] i_win_11,
    input  wire signed [DATA_WIDTH-1:0] i_win_12,
    input  wire signed [DATA_WIDTH-1:0] i_win_20,
    input  wire signed [DATA_WIDTH-1:0] i_win_21,
    input  wire signed [DATA_WIDTH-1:0] i_win_22,

    input  wire signed [OUT_CH*9*DATA_WIDTH-1:0] i_weight_flat,
    input  wire signed [OUT_CH*DATA_WIDTH-1:0]   i_bias_flat,

    output reg                                  o_valid,
    output reg  [7:0]                           o_row,
    output reg  [7:0]                           o_col,
    output reg  signed [OUT_CH*DATA_WIDTH-1:0]  o_data_flat
);

    // ------------------------------------------------------------------------
    // Window and weight unpacking
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] win [0:8];

    assign win[0] = i_win_00;
    assign win[1] = i_win_01;
    assign win[2] = i_win_02;
    assign win[3] = i_win_10;
    assign win[4] = i_win_11;
    assign win[5] = i_win_12;
    assign win[6] = i_win_20;
    assign win[7] = i_win_21;
    assign win[8] = i_win_22;

    wire signed [DATA_WIDTH-1:0] weight [0:OUT_CH-1][0:8];
    wire signed [DATA_WIDTH-1:0] bias   [0:OUT_CH-1];

    genvar oc, k;
    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_UNPACK_CH
            assign bias[oc] = i_bias_flat[oc*DATA_WIDTH +: DATA_WIDTH];
            for (k = 0; k < 9; k = k + 1) begin : GEN_UNPACK_K
                assign weight[oc][k] = i_weight_flat[(oc*9 + k)*DATA_WIDTH +: DATA_WIDTH];
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // 72 multipliers
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] mul_raw [0:OUT_CH-1][0:8];
    reg  signed [ACC_WIDTH-1:0] mul_s1  [0:OUT_CH-1][0:8];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_MAC_CH
            for (k = 0; k < 9; k = k + 1) begin : GEN_MAC_K
                mac_core u_mac_core (
                    .i_data   (win[k]),
                    .i_weight (weight[oc][k]),
                    .o_mul    (mul_raw[oc][k])
                );
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Accumulate 9 products for each output channel.
    // This is after the product register stage, so multiplier -> adder path is cut.
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] acc [0:OUT_CH-1];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_ACC
            assign acc[oc] = mul_s1[oc][0] + mul_s1[oc][1] + mul_s1[oc][2]
                           + mul_s1[oc][3] + mul_s1[oc][4] + mul_s1[oc][5]
                           + mul_s1[oc][6] + mul_s1[oc][7] + mul_s1[oc][8];
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Q8.8 conversion -> bias add -> saturation, then ReLU
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] q_data    [0:OUT_CH-1];
    wire signed [DATA_WIDTH-1:0] relu_data [0:OUT_CH-1];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_POST
            q8_8_unit #(
                .ACC_WIDTH  (ACC_WIDTH),
                .DATA_WIDTH (DATA_WIDTH)
            ) u_q8_8_unit (
                .i_acc  (acc[oc]),
                .i_bias (bias[oc]),
                .o_data (q_data[oc])
            );

            relu u_relu (
                .i_data (q_data[oc]),
                .o_data (relu_data[oc])
            );
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Pipeline registers
    // ------------------------------------------------------------------------
    reg       valid_s1;
    reg [7:0] row_s1;
    reg [7:0] col_s1;

    integer i, j;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_s1    <= 1'b0;
            row_s1      <= 8'd0;
            col_s1      <= 8'd0;
            o_valid     <= 1'b0;
            o_row       <= 8'd0;
            o_col       <= 8'd0;
            o_data_flat <= {OUT_CH*DATA_WIDTH{1'b0}};

            for (i = 0; i < OUT_CH; i = i + 1) begin
                for (j = 0; j < 9; j = j + 1) begin
                    mul_s1[i][j] <= {ACC_WIDTH{1'b0}};
                end
            end
        end else begin
            // Stage 1: register multiplier results and coordinates.
            valid_s1 <= i_valid;
            row_s1   <= i_row;
            col_s1   <= i_col;

            if (i_valid) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    for (j = 0; j < 9; j = j + 1) begin
                        mul_s1[i][j] <= mul_raw[i][j];
                    end
                end
            end

            // Stage 2 output: uses products registered in the previous cycle.
            o_valid <= valid_s1;
            o_row   <= row_s1;
            o_col   <= col_s1;

            if (valid_s1) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    o_data_flat[i*DATA_WIDTH +: DATA_WIDTH] <= relu_data[i];
                end
            end
        end
    end

endmodule
