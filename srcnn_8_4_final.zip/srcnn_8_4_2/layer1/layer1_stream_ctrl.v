`timescale 1ns / 1ps

//============================================================================
// Layer1 stream controller with synchronous input memory support
//----------------------------------------------------------------------------
// - Generates input_mem address one cycle before the pixel is needed.
// - Absorbs the 1-cycle BRAM/ROM read latency using a small FIFO.
// - Feeds Layer1 line buffer only when i_line_ready is high.
// - Adds one bottom zero-padding row after real 150 rows.
//============================================================================

module layer1_stream_ctrl #(
    parameter DATA_WIDTH = 16,
    parameter IMG_W = 150,
    parameter IMG_H = 150,
    parameter ADDR_WIDTH = 17
)(
    input  wire                         clk,
    input  wire                         rst_n,

    input  wire                         i_frame_start,
    input  wire                         i_enable,
    input  wire [1:0]                   i_frame_idx,
    input  wire                         i_line_ready,

    input  wire signed [DATA_WIDTH-1:0] i_mem_data,

    output wire                         o_feed_valid,
    output wire signed [DATA_WIDTH-1:0] o_feed_data,
    output wire [ADDR_WIDTH-1:0]        o_input_addr,
    output reg                          o_feed_done
);

    localparam PIX_PER_IMG  = IMG_W * IMG_H;       // 22500
    localparam TOTAL_FEED   = (IMG_H + 1) * IMG_W; // 22650 including bottom pad row
    localparam FIFO_DEPTH   = 4;

    reg [7:0] row;
    reg [7:0] col;
    reg [15:0] req_count;
    reg running;

    wire [ADDR_WIDTH-1:0] frame_base = (i_frame_idx == 2'd0) ? 17'd0 :
                                       (i_frame_idx == 2'd1) ? 17'd22500 : 17'd45000;

    wire [ADDR_WIDTH-1:0] row_offset = {row, 7'b0} + {row, 4'b0} + {row, 2'b0} + {row, 1'b0}; // row*150
    assign o_input_addr = (row < IMG_H) ? (frame_base + row_offset + col) : frame_base;

    // 1-cycle delayed request metadata, aligned with i_mem_data
    reg rd_valid_d;
    reg rd_is_pad_d;

    // Small FIFO for BRAM output data to survive line-buffer tail cycles
    reg signed [DATA_WIDTH-1:0] fifo_data [0:FIFO_DEPTH-1];
    reg [2:0] fifo_count;

    wire fifo_pop  = (fifo_count != 0) && i_line_ready;
    wire fifo_push = rd_valid_d;

    assign o_feed_valid = fifo_pop;
    assign o_feed_data  = fifo_data[0];

    wire can_issue = running && i_enable && (req_count < TOTAL_FEED) && (fifo_count <= 3'd2);
    wire req_is_pad = (row >= IMG_H);

    integer k;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            row         <= 8'd0;
            col         <= 8'd0;
            req_count   <= 16'd0;
            running     <= 1'b0;
            rd_valid_d  <= 1'b0;
            rd_is_pad_d <= 1'b0;
            fifo_count  <= 3'd0;
            o_feed_done <= 1'b0;
            for (k = 0; k < FIFO_DEPTH; k = k + 1)
                fifo_data[k] <= {DATA_WIDTH{1'b0}};
        end else begin
            o_feed_done <= 1'b0;

            if (i_frame_start) begin
                row         <= 8'd0;
                col         <= 8'd0;
                req_count   <= 16'd0;
                running     <= 1'b1;
                rd_valid_d  <= 1'b0;
                rd_is_pad_d <= 1'b0;
                fifo_count  <= 3'd0;
            end else begin
                // ------------------------------------------------------------
                // FIFO update. Pop first, then push incoming BRAM data.
                // ------------------------------------------------------------
                case ({fifo_push, fifo_pop})
                    2'b00: begin
                        fifo_count <= fifo_count;
                    end
                    2'b01: begin
                        if (fifo_count > 0) begin
                            fifo_data[0] <= fifo_data[1];
                            fifo_data[1] <= fifo_data[2];
                            fifo_data[2] <= fifo_data[3];
                            fifo_data[3] <= {DATA_WIDTH{1'b0}};
                            fifo_count   <= fifo_count - 3'd1;
                        end
                    end
                    2'b10: begin
                        if (fifo_count < FIFO_DEPTH) begin
                            fifo_data[fifo_count] <= rd_is_pad_d ? {DATA_WIDTH{1'b0}} : i_mem_data;
                            fifo_count <= fifo_count + 3'd1;
                        end
                    end
                    2'b11: begin
                        // Pop one and push one in the same cycle.
                        if (fifo_count == 3'd0) begin
                            fifo_data[0] <= rd_is_pad_d ? {DATA_WIDTH{1'b0}} : i_mem_data;
                            fifo_count <= 3'd1;
                        end else begin
                            fifo_data[0] <= fifo_data[1];
                            fifo_data[1] <= fifo_data[2];
                            fifo_data[2] <= fifo_data[3];
                            fifo_data[fifo_count-1] <= rd_is_pad_d ? {DATA_WIDTH{1'b0}} : i_mem_data;
                            fifo_count <= fifo_count;
                        end
                    end
                endcase

                // ------------------------------------------------------------
                // Issue next memory request when FIFO has room.
                // ------------------------------------------------------------
                rd_valid_d  <= can_issue;
                rd_is_pad_d <= req_is_pad;

                if (can_issue) begin
                    req_count <= req_count + 16'd1;

                    if (col == IMG_W-1) begin
                        col <= 8'd0;
                        if (row != IMG_H)
                            row <= row + 8'd1;
                    end else begin
                        col <= col + 8'd1;
                    end
                end else begin
                    rd_valid_d <= 1'b0;
                end

                if (running && (req_count == TOTAL_FEED) && (fifo_count == 0) && !rd_valid_d) begin
                    running     <= 1'b0;
                    o_feed_done <= 1'b1;
                end
            end
        end
    end

endmodule
