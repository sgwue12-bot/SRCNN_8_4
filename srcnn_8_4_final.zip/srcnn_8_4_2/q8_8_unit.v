`timescale 1ns / 1ps

//============================================================================
// Q8.8 fixed-point post-processing unit for SRCNN_8_4
//----------------------------------------------------------------------------
// MAC accumulation(Q16.16)
// -> arithmetic right shift by 8
// -> bias add(Q8.8)
// -> signed saturation/clipping to 16-bit
//
// IMPORTANT:
// Use explicitly signed saturation constants.
// If concatenated constants are left unsigned, Verilog may perform unsigned
// comparisons and negative values can be incorrectly clipped to +32767.
//============================================================================

module q8_8_unit #(
    parameter ACC_WIDTH  = 48,
    parameter DATA_WIDTH = 16
)(
    input  wire signed [ACC_WIDTH-1:0]  i_acc,
    input  wire signed [DATA_WIDTH-1:0] i_bias,
    output wire signed [DATA_WIDTH-1:0] o_data
);

    wire signed [ACC_WIDTH-1:0] acc_shifted;
    wire signed [ACC_WIDTH-1:0] bias_ext;
    wire signed [ACC_WIDTH-1:0] biased;

    // Explicit signed 48-bit saturation bounds
    localparam signed [ACC_WIDTH-1:0] SAT_MAX = {{(ACC_WIDTH-16){1'b0}}, 16'h7FFF};
    localparam signed [ACC_WIDTH-1:0] SAT_MIN = -{{(ACC_WIDTH-16){1'b0}}, 16'h8000};

    assign acc_shifted = i_acc >>> 8;
    assign bias_ext    = {{(ACC_WIDTH-DATA_WIDTH){i_bias[DATA_WIDTH-1]}}, i_bias};
    assign biased      = acc_shifted + bias_ext;

    assign o_data =
        (biased > SAT_MAX) ? 16'sh7FFF :
        (biased < SAT_MIN) ? 16'sh8000 :
                              biased[DATA_WIDTH-1:0];

endmodule
