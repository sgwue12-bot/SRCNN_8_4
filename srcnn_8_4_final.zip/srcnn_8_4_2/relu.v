`timescale 1ns / 1ps

//============================================================================
// ReLU activation module
//----------------------------------------------------------------------------
// Function:
//   if input < 0  -> output = 0
//   if input >= 0 -> output = input
//
// Data format:
//   signed 16-bit Q8.8
//============================================================================

module relu (
    input  wire signed [15:0] i_data,
    output wire signed [15:0] o_data
);

    assign o_data = (i_data[15]) ? 16'sd0 : i_data;

endmodule
