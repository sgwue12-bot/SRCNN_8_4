`timescale 1ns / 1ps

//============================================================================
// Weight / bias ROM for SRCNN_8_4
//----------------------------------------------------------------------------
// Model: 1 -> 8 -> 4 -> 1
// Data : signed Q8.8, 16-bit hex
//
// W1: 8 x 1 x 3 x 3 = 72
// B1: 8
// W2: 4 x 8 x 3 x 3 = 288
// B2: 4
// W3: 1 x 4 x 3 x 3 = 36
// B3: 1
//============================================================================

module weight_bias_mem_8_4 #(
    parameter DATA_WIDTH = 16
)(
    output wire signed [72*DATA_WIDTH-1:0]   o_w1_flat,
    output wire signed [288*DATA_WIDTH-1:0]  o_w2_flat,
    output wire signed [36*DATA_WIDTH-1:0]   o_w3_flat,
    output wire signed [8*DATA_WIDTH-1:0]    o_b1_flat,
    output wire signed [4*DATA_WIDTH-1:0]    o_b2_flat,
    output wire signed [DATA_WIDTH-1:0]      o_b3
);

    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] w1_mem [0:71];
    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] w2_mem [0:287];
    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] w3_mem [0:35];
    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] b1_mem [0:7];
    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] b2_mem [0:3];
    (* rom_style = "distributed" *) reg signed [DATA_WIDTH-1:0] b3_mem [0:0];

`ifdef SYNTHESIS
    initial begin
        $readmemh("../../../01_Reference_SW/q88_8_4weight/fixed_point_W1_hex.txt", w1_mem);
        $readmemh("../../../01_Reference_SW/q88_8_4weight/fixed_point_W2_hex.txt", w2_mem);
        $readmemh("../../../01_Reference_SW/q88_8_4weight/fixed_point_W3_hex.txt", w3_mem);
        $readmemh("../../../01_Reference_SW/q88_8_4bias/fixed_point_B1_hex.txt", b1_mem);
        $readmemh("../../../01_Reference_SW/q88_8_4bias/fixed_point_B2_hex.txt", b2_mem);
        $readmemh("../../../01_Reference_SW/q88_8_4bias/fixed_point_B3_hex.txt", b3_mem);
    end
`else
    initial begin
        $readmemh("../../../../../01_Reference_SW/q88_8_4weight/fixed_point_W1_hex.txt", w1_mem);
        $readmemh("../../../../../01_Reference_SW/q88_8_4weight/fixed_point_W2_hex.txt", w2_mem);
        $readmemh("../../../../../01_Reference_SW/q88_8_4weight/fixed_point_W3_hex.txt", w3_mem);
        $readmemh("../../../../../01_Reference_SW/q88_8_4bias/fixed_point_B1_hex.txt", b1_mem);
        $readmemh("../../../../../01_Reference_SW/q88_8_4bias/fixed_point_B2_hex.txt", b2_mem);
        $readmemh("../../../../../01_Reference_SW/q88_8_4bias/fixed_point_B3_hex.txt", b3_mem);
    end
`endif


    genvar gi;
    generate
        for (gi = 0; gi < 72; gi = gi + 1) begin : GEN_W1_FLAT
            assign o_w1_flat[gi*DATA_WIDTH +: DATA_WIDTH] = w1_mem[gi];
        end
        for (gi = 0; gi < 288; gi = gi + 1) begin : GEN_W2_FLAT
            assign o_w2_flat[gi*DATA_WIDTH +: DATA_WIDTH] = w2_mem[gi];
        end
        for (gi = 0; gi < 36; gi = gi + 1) begin : GEN_W3_FLAT
            assign o_w3_flat[gi*DATA_WIDTH +: DATA_WIDTH] = w3_mem[gi];
        end
        for (gi = 0; gi < 8; gi = gi + 1) begin : GEN_B1_FLAT
            assign o_b1_flat[gi*DATA_WIDTH +: DATA_WIDTH] = b1_mem[gi];
        end
        for (gi = 0; gi < 4; gi = gi + 1) begin : GEN_B2_FLAT
            assign o_b2_flat[gi*DATA_WIDTH +: DATA_WIDTH] = b2_mem[gi];
        end
    endgenerate

    assign o_b3 = b3_mem[0];

endmodule
