`timescale 1ns / 1ps

//============================================================================
// Streaming 3x150 single-channel line buffer with zero padding
//----------------------------------------------------------------------------
// This version uses two circular 1-row delay buffers + 3-column shift registers.
// It keeps the same port list as the previous line_buffer_3x150_1ch module.
//
// Input sequence per frame/channel:
//   - i_frame_start one cycle before first pixel
//   - 150x150 real pixels
//   - 1 bottom-padding row of zeros from the local controller
//   - respect o_in_ready. A tail cycle is inserted after each row.
//
// Window timing:
//   - input col=1 produces output col=0
//   - after input col=149, one tail cycle produces output col=149
//============================================================================

module line_buffer_3x150_1ch #(
    parameter DATA_WIDTH = 16,
    parameter IMG_W      = 150,
    parameter IMG_H      = 150
)(
    input  wire                         clk,
    input  wire                         rst_n,

    input  wire                         i_frame_start,
    input  wire                         i_valid,
    input  wire signed [DATA_WIDTH-1:0] i_data,

    output wire                         o_in_ready,

    output reg                          o_win_valid,
    output reg  [7:0]                   o_out_row,
    output reg  [7:0]                   o_out_col,

    output reg signed [DATA_WIDTH-1:0]  o_win_00,
    output reg signed [DATA_WIDTH-1:0]  o_win_01,
    output reg signed [DATA_WIDTH-1:0]  o_win_02,
    output reg signed [DATA_WIDTH-1:0]  o_win_10,
    output reg signed [DATA_WIDTH-1:0]  o_win_11,
    output reg signed [DATA_WIDTH-1:0]  o_win_12,
    output reg signed [DATA_WIDTH-1:0]  o_win_20,
    output reg signed [DATA_WIDTH-1:0]  o_win_21,
    output reg signed [DATA_WIDTH-1:0]  o_win_22
);

    localparam [7:0] LAST_COL = IMG_W - 1;
    localparam [7:0] PAD_ROW  = IMG_H;      // row 150 is bottom-zero row

    // One-row and two-row circular delay buffers.
    // delay1[wr_col] old value = one row before same column.
    // delay2[wr_col] old value = two rows before same column.
    reg signed [DATA_WIDTH-1:0] delay1 [0:IMG_W-1];
    reg signed [DATA_WIDTH-1:0] delay2 [0:IMG_W-1];

    // Current input coordinate. in_row can be 0..150.
    reg [7:0] in_row;
    reg [7:0] in_col;
    reg       tail_pending;

    // For each of the three row streams, keep the two previous columns.
    // *_left   = col C-2 when current input column is C
    // *_center = col C-1 when current input column is C
    reg signed [DATA_WIDTH-1:0] top_left, top_center;
    reg signed [DATA_WIDTH-1:0] mid_left, mid_center;
    reg signed [DATA_WIDTH-1:0] bot_left, bot_center;

    wire signed [DATA_WIDTH-1:0] zero = {DATA_WIDTH{1'b0}};

    assign o_in_ready = ~tail_pending;

    // Previous row values read from delay buffers. These are old values before
    // the write occurring in this same clock edge.
    wire signed [DATA_WIDTH-1:0] delay1_old = delay1[in_col];
    wire signed [DATA_WIDTH-1:0] delay2_old = delay2[in_col];

    // Guard early rows so uninitialized delay2/delay1 contents never propagate.
    wire signed [DATA_WIDTH-1:0] cur_top = (in_row < 8'd2) ? zero : delay2_old;
    wire signed [DATA_WIDTH-1:0] cur_mid = (in_row < 8'd1) ? zero : delay1_old;
    wire signed [DATA_WIDTH-1:0] cur_bot = i_data;

    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            in_row       <= 8'd0;
            in_col       <= 8'd0;
            tail_pending <= 1'b0;

            top_left     <= zero; top_center <= zero;
            mid_left     <= zero; mid_center <= zero;
            bot_left     <= zero; bot_center <= zero;

            o_win_valid  <= 1'b0;
            o_out_row    <= 8'd0;
            o_out_col    <= 8'd0;

            o_win_00 <= zero; o_win_01 <= zero; o_win_02 <= zero;
            o_win_10 <= zero; o_win_11 <= zero; o_win_12 <= zero;
            o_win_20 <= zero; o_win_21 <= zero; o_win_22 <= zero;
        end else begin
            o_win_valid <= 1'b0;

            if (i_frame_start) begin
                in_row       <= 8'd0;
                in_col       <= 8'd0;
                tail_pending <= 1'b0;

                // Clear only small shift registers and output regs.
                // Delay memories are not cleared for resource efficiency; early-row guards
                // prevent old values from being used.
                top_left     <= zero; top_center <= zero;
                mid_left     <= zero; mid_center <= zero;
                bot_left     <= zero; bot_center <= zero;

                o_win_valid  <= 1'b0;
                o_out_row    <= 8'd0;
                o_out_col    <= 8'd0;

                o_win_00 <= zero; o_win_01 <= zero; o_win_02 <= zero;
                o_win_10 <= zero; o_win_11 <= zero; o_win_12 <= zero;
                o_win_20 <= zero; o_win_21 <= zero; o_win_22 <= zero;

            end else if (tail_pending) begin
                // Right-padding tail window for output col=149.
                if ((in_row >= 8'd1) && (in_row <= PAD_ROW)) begin
                    o_win_valid <= 1'b1;
                    o_out_row   <= in_row - 8'd1;
                    o_out_col   <= LAST_COL;

                    o_win_00 <= top_left;
                    o_win_01 <= top_center;
                    o_win_02 <= zero;

                    o_win_10 <= mid_left;
                    o_win_11 <= mid_center;
                    o_win_12 <= zero;

                    o_win_20 <= bot_left;
                    o_win_21 <= bot_center;
                    o_win_22 <= zero;
                end

                // Prepare next row.
                in_col       <= 8'd0;
                in_row       <= in_row + 8'd1;
                tail_pending <= 1'b0;

                top_left     <= zero; top_center <= zero;
                mid_left     <= zero; mid_center <= zero;
                bot_left     <= zero; bot_center <= zero;

            end else if (i_valid) begin
                // Produce normal window for output col = input col - 1.
                if ((in_col >= 8'd1) && (in_row >= 8'd1) && (in_row <= PAD_ROW)) begin
                    o_win_valid <= 1'b1;
                    o_out_row   <= in_row - 8'd1;
                    o_out_col   <= in_col - 8'd1;

                    o_win_00 <= top_left;
                    o_win_01 <= top_center;
                    o_win_02 <= cur_top;

                    o_win_10 <= mid_left;
                    o_win_11 <= mid_center;
                    o_win_12 <= cur_mid;

                    o_win_20 <= bot_left;
                    o_win_21 <= bot_center;
                    o_win_22 <= cur_bot;
                end

                // Update delay buffers. Old delay1 becomes delay2; input becomes delay1.
                delay1[in_col] <= i_data;
                delay2[in_col] <= delay1_old;

                // Shift current column into 3-column window registers.
                top_left   <= top_center;
                top_center <= cur_top;

                mid_left   <= mid_center;
                mid_center <= cur_mid;

                bot_left   <= bot_center;
                bot_center <= cur_bot;

                // Advance column or schedule right-padding tail.
                if (in_col == LAST_COL) begin
                    tail_pending <= 1'b1;
                end else begin
                    in_col <= in_col + 8'd1;
                end
            end
        end
    end

endmodule
