`timescale 1ns / 1ps

//============================================================================
// MAC multiplication core for SRCNN_8_4
//----------------------------------------------------------------------------
// Function:
//   Q8.8 x Q8.8 = Q16.16
//
// Input:
//   i_data   : signed 16-bit Q8.8
//   i_weight : signed 16-bit Q8.8
//
// Output:
//   o_mul    : signed 48-bit accumulator-scale product
//
// KV260 / Vivado note:
//   The use_dsp attribute nudges Vivado to map this signed multiplier to DSP48
//   instead of LUT logic. The interface remains combinational, so existing
//   conv blocks do not need latency changes.
//============================================================================

module mac_core (
    input  wire signed [15:0] i_data,
    input  wire signed [15:0] i_weight,
    output wire signed [47:0] o_mul
);

    (* use_dsp = "yes" *) wire signed [31:0] product;

    assign product = i_data * i_weight;

    assign o_mul = {{16{product[31]}}, product};

endmodule
