`timescale 1ns / 1ps

//============================================================================
// Input image memory for SRCNN_8_4
//----------------------------------------------------------------------------
// - Reads 3 independent 150x150 Q8.8 hex image files.
// - Uses a single continuous address space for the SRCNN controller:
//     0     ~ 22499 : image 0
//     22500 ~ 44999 : image 1
//     45000 ~ 67499 : image 2
// - Synchronous read, 1-cycle latency, written as a BRAM-friendly ROM template.
//
// NOTE
// - This version intentionally does NOT use XPM, because xpm_memory_sprom
//   requires .mem extension files. $readmemh accepts .txt files.
//============================================================================

module input_mem_3img #(
    parameter ADDR_WIDTH = 17,
    parameter DATA_WIDTH = 16,
    parameter IMG_W      = 150,
    parameter IMG_H      = 150,
    parameter IMG_PIXELS = 22500,
    parameter DEPTH      = 67500
)(
    input  wire                         clk,
    input  wire [ADDR_WIDTH-1:0]        i_addr,
    output reg  signed [DATA_WIDTH-1:0] o_data
);

    // Force block RAM style as much as possible.
    // Vivado may still choose another primitive depending on project settings,
    // but this synchronous-read template is BRAM-friendly.
    (* ram_style = "block" *) reg signed [DATA_WIDTH-1:0] mem [0:DEPTH-1];

   
`ifdef SYNTHESIS
    initial begin
        $readmemh("../../../02_Provided_Data/input_Y_channel_only_hex/test_0_hex.txt", mem, 0,              IMG_PIXELS-1);
        $readmemh("../../../02_Provided_Data/input_Y_channel_only_hex/test_1_hex.txt", mem, IMG_PIXELS,     2*IMG_PIXELS-1);
        $readmemh("../../../02_Provided_Data/input_Y_channel_only_hex/test_2_hex.txt", mem, 2*IMG_PIXELS,   3*IMG_PIXELS-1);

    end
`else
    initial begin
        $readmemh("../../../../../02_Provided_Data/input_Y_channel_only_hex/test_0_hex.txt", mem, 0,              IMG_PIXELS-1);
        $readmemh("../../../../../02_Provided_Data/input_Y_channel_only_hex/test_1_hex.txt", mem, IMG_PIXELS,     2*IMG_PIXELS-1);
        $readmemh("../../../../../02_Provided_Data/input_Y_channel_only_hex/test_2_hex.txt", mem, 2*IMG_PIXELS,   3*IMG_PIXELS-1);

    end
`endif

    always @(posedge clk) begin
        o_data <= mem[i_addr];
    end

endmodule
