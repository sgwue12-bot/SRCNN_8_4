`timescale 1ns / 1ps

//============================================================================
// Layer3 convolution block for SRCNN_8_4
//----------------------------------------------------------------------------
// Function:
//   4 input-channel 3x3 windows -> 1 output-channel pixel
//
// Architecture:
//   - mac_core x 36 = 1 output channel x 4 input channels x 9 kernel taps
//   - Pipelined reduction tree for KV260 timing margin
//   - q8_8_unit x 1 : (MAC accumulation >>> 8) + bias + saturation
//   - No ReLU in Layer3
//
// Fixed-point order, IMPORTANT:
//   Q8.8 input x Q8.8 weight -> Q16.16 product
//   Sum 4*9 products          -> wide accumulator
//   q8_8_unit                 -> arithmetic shift right by 8, then bias add
//   output                    -> final enhanced Y pixel
//
// Input window flat order:
//   i_win_flat[(in_ch*9 + tap)*16 +: 16]
//
// Weight flat order:
//   i_weight_flat[(in_ch*9 + tap)*16 +: 16]
//
// Tap order per channel:
//   tap0 tap1 tap2 = win00 win01 win02
//   tap3 tap4 tap5 = win10 win11 win12
//   tap6 tap7 tap8 = win20 win21 win22
//
// Timing:
//   - Accepts one valid 4-channel window group per cycle when i_valid=1.
//   - o_valid is asserted 3 clocks after the corresponding i_valid.
//============================================================================

module layer3_conv_1ch #(
    parameter DATA_WIDTH = 16,
    parameter ACC_WIDTH  = 48,
    parameter IN_CH      = 4
)(
    input  wire                                      clk,
    input  wire                                      rst_n,

    input  wire                                      i_valid,
    input  wire [7:0]                                i_row,
    input  wire [7:0]                                i_col,

    input  wire signed [IN_CH*9*DATA_WIDTH-1:0]      i_win_flat,
    input  wire signed [IN_CH*9*DATA_WIDTH-1:0]      i_weight_flat,
    input  wire signed [DATA_WIDTH-1:0]              i_bias,

    output reg                                       o_valid,
    output reg  [7:0]                                o_row,
    output reg  [7:0]                                o_col,
    output reg  signed [DATA_WIDTH-1:0]              o_data
);

    // ------------------------------------------------------------------------
    // Unpack input windows and weights
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] win    [0:IN_CH-1][0:8];
    wire signed [DATA_WIDTH-1:0] weight [0:IN_CH-1][0:8];

    genvar ic, k;
    generate
        for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_UNPACK_CH
            for (k = 0; k < 9; k = k + 1) begin : GEN_UNPACK_K
                assign win[ic][k]    = i_win_flat[(ic*9 + k)*DATA_WIDTH +: DATA_WIDTH];
                assign weight[ic][k] = i_weight_flat[(ic*9 + k)*DATA_WIDTH +: DATA_WIDTH];
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // 36 multipliers
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] mul_raw [0:IN_CH-1][0:8];
    reg  signed [ACC_WIDTH-1:0] mul_s1  [0:IN_CH-1][0:8];

    generate
        for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_MAC_IC
            for (k = 0; k < 9; k = k + 1) begin : GEN_MAC_K
                mac_core u_mac_core (
                    .i_data   (win[ic][k]),
                    .i_weight (weight[ic][k]),
                    .o_mul    (mul_raw[ic][k])
                );
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Pipelined reduction tree
    // Stage 2: sum 9 products per input channel
    // Stage 3: sum 4 channel sums to final accumulator
    // Stage 4/output: q8_8_unit, no ReLU
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] ch_sum_w [0:IN_CH-1];
    reg  signed [ACC_WIDTH-1:0] ch_sum_s2 [0:IN_CH-1];

    wire signed [ACC_WIDTH-1:0] pair_sum0_w;
    wire signed [ACC_WIDTH-1:0] pair_sum1_w;
    reg  signed [ACC_WIDTH-1:0] pair_sum0_s3;
    reg  signed [ACC_WIDTH-1:0] pair_sum1_s3;

    wire signed [ACC_WIDTH-1:0] acc_final;

    generate
        for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_CH_SUM
            assign ch_sum_w[ic] = mul_s1[ic][0] + mul_s1[ic][1] + mul_s1[ic][2]
                              + mul_s1[ic][3] + mul_s1[ic][4] + mul_s1[ic][5]
                              + mul_s1[ic][6] + mul_s1[ic][7] + mul_s1[ic][8];
        end
    endgenerate

    assign pair_sum0_w = ch_sum_s2[0] + ch_sum_s2[1];
    assign pair_sum1_w = ch_sum_s2[2] + ch_sum_s2[3];
    assign acc_final   = pair_sum0_s3 + pair_sum1_s3;

    // ------------------------------------------------------------------------
    // Q8.8 conversion -> bias add -> saturation
    // Layer3 has no ReLU.
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] q_data;

    q8_8_unit #(
        .ACC_WIDTH  (ACC_WIDTH),
        .DATA_WIDTH (DATA_WIDTH)
    ) u_q8_8_unit (
        .i_acc  (acc_final),
        .i_bias (i_bias),
        .o_data (q_data)
    );

    // ------------------------------------------------------------------------
    // Pipeline control and data registers
    // ------------------------------------------------------------------------
    reg       valid_s1, valid_s2, valid_s3;
    reg [7:0] row_s1, row_s2, row_s3;
    reg [7:0] col_s1, col_s2, col_s3;

    integer i, j;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_s1 <= 1'b0;
            valid_s2 <= 1'b0;
            valid_s3 <= 1'b0;
            o_valid  <= 1'b0;

            row_s1 <= 8'd0; row_s2 <= 8'd0; row_s3 <= 8'd0; o_row <= 8'd0;
            col_s1 <= 8'd0; col_s2 <= 8'd0; col_s3 <= 8'd0; o_col <= 8'd0;
            o_data <= {DATA_WIDTH{1'b0}};

            pair_sum0_s3 <= {ACC_WIDTH{1'b0}};
            pair_sum1_s3 <= {ACC_WIDTH{1'b0}};

            for (i = 0; i < IN_CH; i = i + 1) begin
                ch_sum_s2[i] <= {ACC_WIDTH{1'b0}};
                for (j = 0; j < 9; j = j + 1) begin
                    mul_s1[i][j] <= {ACC_WIDTH{1'b0}};
                end
            end
        end else begin
            // Valid/coordinate pipeline
            valid_s1 <= i_valid;
            valid_s2 <= valid_s1;
            valid_s3 <= valid_s2;
            o_valid  <= valid_s3;

            row_s1 <= i_row;
            row_s2 <= row_s1;
            row_s3 <= row_s2;
            o_row  <= row_s3;

            col_s1 <= i_col;
            col_s2 <= col_s1;
            col_s3 <= col_s2;
            o_col  <= col_s3;

            // Stage 1: register multiplier products
            if (i_valid) begin
                for (i = 0; i < IN_CH; i = i + 1) begin
                    for (j = 0; j < 9; j = j + 1) begin
                        mul_s1[i][j] <= mul_raw[i][j];
                    end
                end
            end

            // Stage 2: register 9-tap sums per input channel
            if (valid_s1) begin
                for (i = 0; i < IN_CH; i = i + 1) begin
                    ch_sum_s2[i] <= ch_sum_w[i];
                end
            end

            // Stage 3: register channel-pair sums
            if (valid_s2) begin
                pair_sum0_s3 <= pair_sum0_w;
                pair_sum1_s3 <= pair_sum1_w;
            end

            // Stage 4/output: q8.8 conversion and bias add only
            if (valid_s3) begin
                o_data <= q_data;
            end
        end
    end

endmodule
