`timescale 1ns / 1ps

//============================================================================
// Layer3 Local Controller for SRCNN_8_4
//----------------------------------------------------------------------------
// Functions:
//   1) Receive Layer2 4-channel output stream
//   2) Feed Layer3 4-channel line buffer
//   3) Insert one bottom zero-padding row after Layer2 last pixel
//   4) Receive Layer3 convolution output stream
//   5) Generate registered final output write interface for top_srcnn.v
//   6) Generate delayed output_last_pixel pulse for board-safe done timing
//
// Output write protocol:
//   - o_output_bram_wen/o_output_bram_waddr/o_L3_p_out are registered together
//   - This matches the successful previous structure where output control was
//     isolated from the top packing block.
//   - Address is global image address:
//       image0: 0     ~ 22499
//       image1: 22500 ~ 44999
//       image2: 45000 ~ 67499
//============================================================================

module layer3_local_ctrl #(
    parameter DATA_WIDTH = 16,
    parameter IN_CH      = 4,
    parameter IMG_W      = 150,
    parameter IMG_H      = 150,
    parameter ADDR_WIDTH = 17,
    parameter DONE_DELAY = 32
)(
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         i_frame_start,
    input  wire [1:0]                   i_frame_idx,

    // Layer2 output stream -> Layer3 line buffer input
    input  wire                         i_l2_valid,
    input  wire [7:0]                   i_l2_row,
    input  wire [7:0]                   i_l2_col,
    input  wire signed [IN_CH*DATA_WIDTH-1:0] i_l2_data_flat,
    input  wire                         i_line_ready,

    output wire                         o_l3_in_valid,
    output wire signed [IN_CH*DATA_WIDTH-1:0] o_l3_in_data_flat,
    output reg                          o_pad_active,

    // Layer3 convolution output stream
    input  wire                         i_l3_out_valid,
    input  wire [7:0]                   i_l3_out_row,
    input  wire [7:0]                   i_l3_out_col,
    input  wire signed [DATA_WIDTH-1:0] i_l3_out_data,

    // Registered final output write interface to top_srcnn.v
    output reg                          o_output_bram_wen,
    output reg  [ADDR_WIDTH-1:0]        o_output_bram_waddr,
    output reg  [DATA_WIDTH-1:0]        o_L3_p_out,

    // Delayed last pixel pulse to global_controller
    output reg                          o_output_last_pixel
);

    // ---------------------------------------------------------------------
    // Bottom padding row insertion for Layer3 input line buffer
    // ---------------------------------------------------------------------
    reg [7:0] pad_col;

    wire l2_last_pixel = i_l2_valid &&
                         (i_l2_row == (IMG_H-1)) &&
                         (i_l2_col == (IMG_W-1));

    wire pad_accept = o_pad_active && i_line_ready;

    assign o_l3_in_valid     = i_l2_valid || pad_accept;
    assign o_l3_in_data_flat = i_l2_valid ? i_l2_data_flat
                                          : {IN_CH*DATA_WIDTH{1'b0}};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_pad_active <= 1'b0;
            pad_col      <= 8'd0;
        end else begin
            if (i_frame_start) begin
                o_pad_active <= 1'b0;
                pad_col      <= 8'd0;
            end else if (l2_last_pixel) begin
                o_pad_active <= 1'b1;
                pad_col      <= 8'd0;
            end else if (pad_accept) begin
                if (pad_col == (IMG_W-1)) begin
                    o_pad_active <= 1'b0;
                    pad_col      <= 8'd0;
                end else begin
                    pad_col <= pad_col + 8'd1;
                end
            end
        end
    end

    // ---------------------------------------------------------------------
    // Registered output write interface
    // ---------------------------------------------------------------------
    wire [ADDR_WIDTH-1:0] output_frame_base =
        (i_frame_idx == 2'd0) ? 17'd0     :
        (i_frame_idx == 2'd1) ? 17'd22500 :
                                17'd45000;

    wire [ADDR_WIDTH-1:0] row_offset =
        {i_l3_out_row, 7'b0} + {i_l3_out_row, 4'b0} +
        {i_l3_out_row, 2'b0} + {i_l3_out_row, 1'b0}; // row * 150

    wire [ADDR_WIDTH-1:0] output_addr_now =
        output_frame_base + row_offset + i_l3_out_col;

    wire last_pixel_now = i_l3_out_valid &&
                          (i_l3_out_row == (IMG_H-1)) &&
                          (i_l3_out_col == (IMG_W-1));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_output_bram_wen   <= 1'b0;
            o_output_bram_waddr <= {ADDR_WIDTH{1'b0}};
            o_L3_p_out          <= {DATA_WIDTH{1'b0}};
        end else begin
            if (i_frame_start) begin
                o_output_bram_wen   <= 1'b0;
                o_output_bram_waddr <= {ADDR_WIDTH{1'b0}};
                o_L3_p_out          <= {DATA_WIDTH{1'b0}};
            end else begin
                o_output_bram_wen <= i_l3_out_valid;

                if (i_l3_out_valid) begin
                    o_output_bram_waddr <= output_addr_now;
                    o_L3_p_out          <= i_l3_out_data;
                end
            end
        end
    end

    // ---------------------------------------------------------------------
    // Board-safe done timing delay
    // ---------------------------------------------------------------------
    reg        done_delay_active;
    reg [7:0]  done_delay_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            done_delay_active    <= 1'b0;
            done_delay_cnt       <= 8'd0;
            o_output_last_pixel  <= 1'b0;
        end else begin
            o_output_last_pixel <= 1'b0;

            if (i_frame_start) begin
                done_delay_active   <= 1'b0;
                done_delay_cnt      <= 8'd0;
                o_output_last_pixel <= 1'b0;
            end else if (last_pixel_now) begin
                done_delay_active <= 1'b1;
                done_delay_cnt    <= 8'd0;
            end else if (done_delay_active) begin
                if (done_delay_cnt == (DONE_DELAY-1)) begin
                    o_output_last_pixel <= 1'b1;
                    done_delay_active   <= 1'b0;
                    done_delay_cnt      <= 8'd0;
                end else begin
                    done_delay_cnt <= done_delay_cnt + 8'd1;
                end
            end
        end
    end

endmodule
