`timescale 1ns / 1ps

//============================================================================
// Layer2 convolution block for SRCNN_8_4
//----------------------------------------------------------------------------
// Function:
//   8 input-channel 3x3 windows -> 4 output-channel pixels
//
// Architecture:
//   - mac_core x 288 = 4 output channels x 8 input channels x 9 kernel taps
//   - Pipelined reduction tree to reduce critical path on KV260
//   - q8_8_unit x 4 : (MAC accumulation >>> 8) + bias + saturation
//   - relu x 4      : Layer2 activation
//
// Fixed-point order, IMPORTANT:
//   Q8.8 input x Q8.8 weight -> Q16.16 product
//   Sum 8*9 products          -> wide accumulator
//   q8_8_unit                 -> arithmetic shift right by 8, then bias add
//   relu                      -> Layer2 ReLU
//
// Input window flat order:
//   i_win_flat[(in_ch*9 + tap)*16 +: 16]
//
// Weight flat order:
//   i_weight_flat[((out_ch*IN_CH*9) + (in_ch*9) + tap)*16 +: 16]
//
// Output flat order:
//   o_data_flat[out_ch*16 +: 16]
//
// Timing:
//   - Accepts one valid 8-channel window group per cycle when i_valid=1.
//   - o_valid is asserted 4 clocks after the corresponding i_valid.
//============================================================================

module layer2_conv_4ch #(
    parameter DATA_WIDTH = 16,
    parameter ACC_WIDTH  = 48,
    parameter IN_CH      = 8,
    parameter OUT_CH     = 4
)(
    input  wire                                      clk,
    input  wire                                      rst_n,

    input  wire                                      i_valid,
    input  wire [7:0]                                i_row,
    input  wire [7:0]                                i_col,

    input  wire signed [IN_CH*9*DATA_WIDTH-1:0]      i_win_flat,
    input  wire signed [OUT_CH*IN_CH*9*DATA_WIDTH-1:0] i_weight_flat,
    input  wire signed [OUT_CH*DATA_WIDTH-1:0]       i_bias_flat,

    output reg                                       o_valid,
    output reg  [7:0]                                o_row,
    output reg  [7:0]                                o_col,
    output reg  signed [OUT_CH*DATA_WIDTH-1:0]       o_data_flat
);

    // ------------------------------------------------------------------------
    // Unpack input windows, weights, and biases
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] win    [0:IN_CH-1][0:8];
    wire signed [DATA_WIDTH-1:0] weight [0:OUT_CH-1][0:IN_CH-1][0:8];
    wire signed [DATA_WIDTH-1:0] bias   [0:OUT_CH-1];

    genvar oc, ic, k;
    generate
        for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_UNPACK_WIN_CH
            for (k = 0; k < 9; k = k + 1) begin : GEN_UNPACK_WIN_K
                assign win[ic][k] = i_win_flat[(ic*9 + k)*DATA_WIDTH +: DATA_WIDTH];
            end
        end

        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_UNPACK_W_OC
            assign bias[oc] = i_bias_flat[oc*DATA_WIDTH +: DATA_WIDTH];
            for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_UNPACK_W_IC
                for (k = 0; k < 9; k = k + 1) begin : GEN_UNPACK_W_K
                    assign weight[oc][ic][k] = i_weight_flat[((oc*IN_CH*9) + (ic*9) + k)*DATA_WIDTH +: DATA_WIDTH];
                end
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // 288 multipliers
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] mul_raw [0:OUT_CH-1][0:IN_CH-1][0:8];
    reg  signed [ACC_WIDTH-1:0] mul_s1  [0:OUT_CH-1][0:IN_CH-1][0:8];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_MAC_OC
            for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_MAC_IC
                for (k = 0; k < 9; k = k + 1) begin : GEN_MAC_K
                    mac_core u_mac_core (
                        .i_data   (win[ic][k]),
                        .i_weight (weight[oc][ic][k]),
                        .o_mul    (mul_raw[oc][ic][k])
                    );
                end
            end
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Pipelined reduction tree
    // Stage 2: sum 9 products per input channel, per output channel
    // Stage 3: sum input-channel pairs: (0+1), (2+3), (4+5), (6+7)
    // Stage 4: sum pair groups: ((0+1)+(2+3)), ((4+5)+(6+7))
    // Stage 5/output: final sum -> q8_8_unit -> ReLU -> output register
    // ------------------------------------------------------------------------
    wire signed [ACC_WIDTH-1:0] ch_sum_w [0:OUT_CH-1][0:IN_CH-1];
    reg  signed [ACC_WIDTH-1:0] ch_sum_s2 [0:OUT_CH-1][0:IN_CH-1];

    wire signed [ACC_WIDTH-1:0] pair_sum_w [0:OUT_CH-1][0:3];
    reg  signed [ACC_WIDTH-1:0] pair_sum_s3 [0:OUT_CH-1][0:3];

    wire signed [ACC_WIDTH-1:0] half_sum_w [0:OUT_CH-1][0:1];
    reg  signed [ACC_WIDTH-1:0] half_sum_s4 [0:OUT_CH-1][0:1];

    wire signed [ACC_WIDTH-1:0] acc_final [0:OUT_CH-1];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_REDUCE_OC
            for (ic = 0; ic < IN_CH; ic = ic + 1) begin : GEN_CH_SUM
                assign ch_sum_w[oc][ic] = mul_s1[oc][ic][0] + mul_s1[oc][ic][1] + mul_s1[oc][ic][2]
                                      + mul_s1[oc][ic][3] + mul_s1[oc][ic][4] + mul_s1[oc][ic][5]
                                      + mul_s1[oc][ic][6] + mul_s1[oc][ic][7] + mul_s1[oc][ic][8];
            end

            assign pair_sum_w[oc][0] = ch_sum_s2[oc][0] + ch_sum_s2[oc][1];
            assign pair_sum_w[oc][1] = ch_sum_s2[oc][2] + ch_sum_s2[oc][3];
            assign pair_sum_w[oc][2] = ch_sum_s2[oc][4] + ch_sum_s2[oc][5];
            assign pair_sum_w[oc][3] = ch_sum_s2[oc][6] + ch_sum_s2[oc][7];

            assign half_sum_w[oc][0] = pair_sum_s3[oc][0] + pair_sum_s3[oc][1];
            assign half_sum_w[oc][1] = pair_sum_s3[oc][2] + pair_sum_s3[oc][3];

            assign acc_final[oc] = half_sum_s4[oc][0] + half_sum_s4[oc][1];
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Q8.8 conversion -> bias add -> saturation, then ReLU
    // ------------------------------------------------------------------------
    wire signed [DATA_WIDTH-1:0] q_data    [0:OUT_CH-1];
    wire signed [DATA_WIDTH-1:0] relu_data [0:OUT_CH-1];

    generate
        for (oc = 0; oc < OUT_CH; oc = oc + 1) begin : GEN_POST
            q8_8_unit #(
                .ACC_WIDTH  (ACC_WIDTH),
                .DATA_WIDTH (DATA_WIDTH)
            ) u_q8_8_unit (
                .i_acc  (acc_final[oc]),
                .i_bias (bias[oc]),
                .o_data (q_data[oc])
            );

            relu u_relu (
                .i_data (q_data[oc]),
                .o_data (relu_data[oc])
            );
        end
    endgenerate

    // ------------------------------------------------------------------------
    // Pipeline control and data registers
    // ------------------------------------------------------------------------
    reg       valid_s1, valid_s2, valid_s3, valid_s4;
    reg [7:0] row_s1, row_s2, row_s3, row_s4;
    reg [7:0] col_s1, col_s2, col_s3, col_s4;

    integer i, j, t;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            valid_s1    <= 1'b0;
            valid_s2    <= 1'b0;
            valid_s3    <= 1'b0;
            valid_s4    <= 1'b0;
            o_valid     <= 1'b0;

            row_s1 <= 8'd0; row_s2 <= 8'd0; row_s3 <= 8'd0; row_s4 <= 8'd0; o_row <= 8'd0;
            col_s1 <= 8'd0; col_s2 <= 8'd0; col_s3 <= 8'd0; col_s4 <= 8'd0; o_col <= 8'd0;
            o_data_flat <= {OUT_CH*DATA_WIDTH{1'b0}};

            for (i = 0; i < OUT_CH; i = i + 1) begin
                for (j = 0; j < IN_CH; j = j + 1) begin
                    ch_sum_s2[i][j] <= {ACC_WIDTH{1'b0}};
                    for (t = 0; t < 9; t = t + 1) begin
                        mul_s1[i][j][t] <= {ACC_WIDTH{1'b0}};
                    end
                end
                for (j = 0; j < 4; j = j + 1) begin
                    pair_sum_s3[i][j] <= {ACC_WIDTH{1'b0}};
                end
                for (j = 0; j < 2; j = j + 1) begin
                    half_sum_s4[i][j] <= {ACC_WIDTH{1'b0}};
                end
            end
        end else begin
            // Valid/coordinate pipeline
            valid_s1 <= i_valid;
            valid_s2 <= valid_s1;
            valid_s3 <= valid_s2;
            valid_s4 <= valid_s3;
            o_valid  <= valid_s4;

            row_s1 <= i_row;
            row_s2 <= row_s1;
            row_s3 <= row_s2;
            row_s4 <= row_s3;
            o_row  <= row_s4;

            col_s1 <= i_col;
            col_s2 <= col_s1;
            col_s3 <= col_s2;
            col_s4 <= col_s3;
            o_col  <= col_s4;

            // Stage 1: register multiplier products
            if (i_valid) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    for (j = 0; j < IN_CH; j = j + 1) begin
                        for (t = 0; t < 9; t = t + 1) begin
                            mul_s1[i][j][t] <= mul_raw[i][j][t];
                        end
                    end
                end
            end

            // Stage 2: register 9-tap sums per input channel
            if (valid_s1) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    for (j = 0; j < IN_CH; j = j + 1) begin
                        ch_sum_s2[i][j] <= ch_sum_w[i][j];
                    end
                end
            end

            // Stage 3: register channel-pair sums
            if (valid_s2) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    for (j = 0; j < 4; j = j + 1) begin
                        pair_sum_s3[i][j] <= pair_sum_w[i][j];
                    end
                end
            end

            // Stage 4: register half sums
            if (valid_s3) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    for (j = 0; j < 2; j = j + 1) begin
                        half_sum_s4[i][j] <= half_sum_w[i][j];
                    end
                end
            end

            // Stage 5/output: final q8.8 conversion, bias add, ReLU
            if (valid_s4) begin
                for (i = 0; i < OUT_CH; i = i + 1) begin
                    o_data_flat[i*DATA_WIDTH +: DATA_WIDTH] <= relu_data[i];
                end
            end
        end
    end

endmodule
