`timescale 1ns / 1ps

//============================================================================
// Layer2 input line-buffer wrapper for SRCNN_8_4
//----------------------------------------------------------------------------
// Function:
//   - Receive 8-channel Layer1 output pixels every valid cycle.
//   - Store each channel in its own 3x150 line buffer.
//   - Generate 8 parallel 3x3 windows for Layer2 convolution.
//
// Architecture:
//   - line_buffer_3x150_1ch x 8
//   - No full-frame feature-map BRAM between Layer1 and Layer2.
//   - Each channel line buffer uses row-pointer rotation internally.
//
// Timing/Handshake:
//   - i_valid is accepted only when o_in_ready = 1.
//   - o_in_ready is AND of all channel line-buffer ready signals.
//   - Since all 8 channel buffers share the same frame_start/valid timing,
//     their ready and valid signals should stay aligned.
//
// Input flat order:
//   i_data_flat[ch*16 +: 16]
//
// Output flat window order:
//   o_win_flat[(ch*9 + tap)*16 +: 16]
//
// Tap order per channel:
//   tap0 tap1 tap2 = win00 win01 win02
//   tap3 tap4 tap5 = win10 win11 win12
//   tap6 tap7 tap8 = win20 win21 win22
//============================================================================

module layer2_linebuf_8ch #(
    parameter DATA_WIDTH = 16,
    parameter IMG_W      = 150,
    parameter IMG_H      = 150,
    parameter IN_CH      = 8
)(
    input  wire                                clk,
    input  wire                                rst_n,

    input  wire                                i_frame_start,
    input  wire                                i_valid,
    input  wire signed [IN_CH*DATA_WIDTH-1:0] i_data_flat,

    output wire                                o_in_ready,

    output wire                                o_win_valid,
    output wire [7:0]                          o_out_row,
    output wire [7:0]                          o_out_col,
    output wire signed [IN_CH*9*DATA_WIDTH-1:0] o_win_flat
);

    wire [IN_CH-1:0] ready_ch;
    wire [IN_CH-1:0] valid_ch;

    wire [7:0] row_ch [0:IN_CH-1];
    wire [7:0] col_ch [0:IN_CH-1];

    wire signed [DATA_WIDTH-1:0] win00 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win01 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win02 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win10 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win11 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win12 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win20 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win21 [0:IN_CH-1];
    wire signed [DATA_WIDTH-1:0] win22 [0:IN_CH-1];

    assign o_in_ready = &ready_ch;
    assign o_win_valid = &valid_ch;

    // All channel buffers are synchronized. Use ch0 coordinate as common coord.
    assign o_out_row = row_ch[0];
    assign o_out_col = col_ch[0];

    genvar ch;
    generate
        for (ch = 0; ch < IN_CH; ch = ch + 1) begin : GEN_L2_LINEBUF
            line_buffer_3x150_1ch #(
                .DATA_WIDTH (DATA_WIDTH),
                .IMG_W      (IMG_W),
                .IMG_H      (IMG_H)
            ) u_line_buffer_3x150_1ch (
                .clk           (clk),
                .rst_n         (rst_n),
                .i_frame_start (i_frame_start),
                .i_valid       (i_valid & o_in_ready),
                .i_data        (i_data_flat[ch*DATA_WIDTH +: DATA_WIDTH]),
                .o_in_ready    (ready_ch[ch]),
                .o_win_valid   (valid_ch[ch]),
                .o_out_row     (row_ch[ch]),
                .o_out_col     (col_ch[ch]),
                .o_win_00      (win00[ch]),
                .o_win_01      (win01[ch]),
                .o_win_02      (win02[ch]),
                .o_win_10      (win10[ch]),
                .o_win_11      (win11[ch]),
                .o_win_12      (win12[ch]),
                .o_win_20      (win20[ch]),
                .o_win_21      (win21[ch]),
                .o_win_22      (win22[ch])
            );

            assign o_win_flat[(ch*9 + 0)*DATA_WIDTH +: DATA_WIDTH] = win00[ch];
            assign o_win_flat[(ch*9 + 1)*DATA_WIDTH +: DATA_WIDTH] = win01[ch];
            assign o_win_flat[(ch*9 + 2)*DATA_WIDTH +: DATA_WIDTH] = win02[ch];
            assign o_win_flat[(ch*9 + 3)*DATA_WIDTH +: DATA_WIDTH] = win10[ch];
            assign o_win_flat[(ch*9 + 4)*DATA_WIDTH +: DATA_WIDTH] = win11[ch];
            assign o_win_flat[(ch*9 + 5)*DATA_WIDTH +: DATA_WIDTH] = win12[ch];
            assign o_win_flat[(ch*9 + 6)*DATA_WIDTH +: DATA_WIDTH] = win20[ch];
            assign o_win_flat[(ch*9 + 7)*DATA_WIDTH +: DATA_WIDTH] = win21[ch];
            assign o_win_flat[(ch*9 + 8)*DATA_WIDTH +: DATA_WIDTH] = win22[ch];
        end
    endgenerate

endmodule
