`timescale 1ns / 1ps

module layer2_local_ctrl #(
    parameter DATA_WIDTH = 16,
    parameter IN_CH = 8,
    parameter IMG_W = 150
)(
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         i_frame_start,

    input  wire                         i_l1_valid,
    input  wire [7:0]                   i_l1_row,
    input  wire [7:0]                   i_l1_col,
    input  wire signed [IN_CH*DATA_WIDTH-1:0] i_l1_data_flat,

    input  wire                         i_line_ready,

    output wire                         o_l2_in_valid,
    output wire signed [IN_CH*DATA_WIDTH-1:0] o_l2_in_data_flat,
    output reg                          o_pad_active
);

    reg [7:0] pad_col;

    wire l1_last_pixel = i_l1_valid && (i_l1_row == 8'd149) && (i_l1_col == 8'd149);
    wire pad_accept    = o_pad_active && i_line_ready;

    // IMPORTANT: This controller assumes the upstream Layer1 stream is not stalled here.
    // If timing simulation shows i_l1_valid while i_line_ready=0, insert a small FIFO before this block.
    assign o_l2_in_valid     = i_l1_valid || pad_accept;
    assign o_l2_in_data_flat = i_l1_valid ? i_l1_data_flat : {IN_CH*DATA_WIDTH{1'b0}};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            o_pad_active <= 1'b0;
            pad_col      <= 8'd0;
        end else begin
            if (i_frame_start) begin
                o_pad_active <= 1'b0;
                pad_col      <= 8'd0;
            end else if (l1_last_pixel) begin
                o_pad_active <= 1'b1;
                pad_col      <= 8'd0;
            end else if (pad_accept) begin
                if (pad_col == IMG_W-1) begin
                    o_pad_active <= 1'b0;
                    pad_col      <= 8'd0;
                end else begin
                    pad_col <= pad_col + 8'd1;
                end
            end
        end
    end

endmodule
